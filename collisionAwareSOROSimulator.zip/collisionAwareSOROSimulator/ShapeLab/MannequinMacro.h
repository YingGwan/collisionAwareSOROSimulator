#pragma once

#define MAN_CHAMBER_SIZE 1		//twisting robot case: should not change this

